 <footer id="footer">
     <div class="footer-top">
         <div class="container">
             <div class="row">
                 <div class="col-md-3">
                     <div class="footer-widget">
                         <h3>Your check link</h3>
                         <ul>
                             <li><a href="accepted_appoint.php">Accepted appointment List</a></li>
                             <li><a href="vip_cust.php">VIP Customer List</a></li>
                         </ul>
                     </div>
                 </div>
                 <div class="col-md-3">
                     <div class="footer-widget">
                         <h3>Quick Links</h3>
                         <ul>
                             <li><a href="about-us.php">About Us</a></li>
                             <li><a href="services.php">Procedures</a></li>
                             <li><a href="gallery.php">Gallery</a></li>
                             <li><a href="contact-us.php">Contact Us</a></li>
                         </ul>
                     </div>
                 </div>
                 <div class="col-md-3">
                     <div class="footer-widget">
                         <h3>Contact Info</h3>
                         <ul>
                             <li><i class="fa fa-send" aria-hidden="true"></i> Lagro, Quezon City, Metro Manila</li>
                             <li><i class="fa fa-phone" aria-hidden="true"></i> +93123 4567890</li>
                             <li><i class="fa fa-envelope-o" aria-hidden="true"></i> brotherbear@gmail.com</li>
                             <li><i class="fa fa-fax" aria-hidden="true"></i> Fax : 02 9875 5432</li>
                         </ul>
                     </div>
                 </div>
                 <div class="col-md-3">
                     <div class="footer-widget">
                         
                     </div>
                 </div>
             </div>
         </div>
     </div>
     <div class="footer-bottom">
         <div class="container">
             <div class="row">
                 <div class="col-sm-12 col-md-6">
                     <div class="copyright">
                         <p class="text-center">Copyright &copy; 2023. Chic Beauty Salon</p>
                     </div>
                 </div>
                 <div class="col-sm-12 col-md-6">
                     <ul class="social-icons pull-right">
                         <li><a href="#" target="_blank"><i class="fa fa-facebook"></i></a></li>
                         <li><a href="#" target="_blank"><i class="fa fa-twitter"></i></a></li>
                         <li><a href="#" target="_blank"><i class="fa fa-linkedin"></i></a></li>
                         <li><a href="#" target="_blank"><i class="fa fa-instagram"></i></a></li>
                     </ul>
                 </div>
             </div>
     </div>
</div>

 </footer>
