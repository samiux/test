<!--footer-->
    <div class="footer">
       <p>&copy; 2023 Chic Beauty Salon Admin Panel.</p>
    </div>
        <!--//footer-->